//
//  Extension.swift
//  Created by Solcall Services on 03/9/19.
//  Copyright © 2019 Solcall Services. All rights reserved.
//

import Foundation
import UIKit
private var kAssociationKeyMaxLength: Int = 0
@IBDesignable extension UIView {
    @IBInspectable var borderColor: UIColor? {
        set {
            layer.borderColor = newValue?.cgColor
        }
        get {
            guard let color = layer.borderColor else {
                return nil
            }
            return UIColor(cgColor: color)
        }
    }
    @IBInspectable var borderWidth: CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    @IBInspectable var cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
    
}

extension String {
    func isEqualToString(find: String) -> Bool {
        return String(format: self) == find
    }
}
var textGray: UIColor {
    return UIColor(red: 102.0 / 255.0, green: 102.0 / 255.0, blue: 102.0 / 255.0, alpha: 1.0)
}
var logoLightBlue: UIColor {
    return UIColor(red: 0.0 / 255.0, green: 166.0 / 255.0, blue: 237.0 / 255.0, alpha: 1.0)
}
var defaultPurple: UIColor {
    return UIColor(red: 103.0 / 255.0, green: 58.0 / 255.0, blue: 183.0 / 255.0, alpha: 1.0)
}

var defaultLightGray: UIColor {
    return UIColor(white: 224.0 / 255.0, alpha: 1.0)
}

var defaultSteelGrey: UIColor {
    return UIColor(red: 121.0 / 255.0, green: 130.0 / 255.0, blue: 133.0 / 255.0, alpha: 1.0)
}
extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
}
extension String {
   
 
    
    static let no_internet = NSLocalizedString("Your internet Connection appears to be offline", comment: "")
    static let server_error = NSLocalizedString("Something Went Wrong", comment: "")
    
    static let reject_text = NSLocalizedString("Are you sure you want to reject?", comment: "")
    static let approve_text = NSLocalizedString("Are you sure you want to approve?", comment: "")
    static let signout_text = NSLocalizedString("Are You Sure Want to Log Out?", comment: "")
    static let delete_member = NSLocalizedString("Are You Sure Want to Delete This Member?", comment: "")
    static let enter_username = NSLocalizedString("Please enter username", comment: "")
    static let enter_firstname = NSLocalizedString("Enter First Name", comment: "")
    static let enter_lastname = NSLocalizedString("Enter Last Name", comment: "")
    static let enter_password = NSLocalizedString("Please enter password", comment: "")
    static let enter_email = NSLocalizedString("Enter Email", comment: "")
    static let oldPassword = NSLocalizedString("Enter Old Password", comment: "")
    static let newPassword = NSLocalizedString("Enter New Password", comment: "")
    static let confirmPassword = NSLocalizedString("Re-enter New Password", comment: "")
    
    static let confirmPasswordmatch = NSLocalizedString("New Password and Re-enter New Password Should Be Same", comment: "")
    static let validEmail = NSLocalizedString("Enter a Valid Email", comment: "")
    static let validmobile = NSLocalizedString("Enter a Valid Mobile Number", comment: "")
    static let enter_name = NSLocalizedString("Enter Name", comment: "")
    
    static let imagebaseURL = NSLocalizedString("", comment: "")
    static let enter_compnyname = NSLocalizedString("Enter Insurance Company Name", comment: "")
    static let select_compnyname = NSLocalizedString("Select Insurance Company", comment: "")
    static let enter_memberid = NSLocalizedString("Enter Member Id", comment: "")
    static let enter_group = NSLocalizedString("Enter Group", comment: "")
    static let enter_rxbin = NSLocalizedString("Enter Rx BIN", comment: "")
    static let enter_rxpcn = NSLocalizedString("Enter Rx PCN", comment: "")
    static let enter_rxgroup = NSLocalizedString("Enter Rx Group", comment: "")
    static let enter_zip = NSLocalizedString("Enter Home Zip Code", comment: "")
    static let enter_pharmacy = NSLocalizedString("Select Pharmacy", comment: "")
    static let enter_nameonCard = NSLocalizedString("Enter Name as on Card", comment: "")
    
}


enum enumAnimation {
    case fadeIn,bounce,moveIn,side,leftIn,rightIn
    var displayName : String{
        switch self {
        case .fadeIn:
            return "FadeIn animation"
        case .bounce:
            return "Bouncing Animation"
        case .moveIn:
            return "MoveIn Animation"
        case .side:
            return "Side(left/right) Animation"
        case .leftIn:
            return "LeftIn Animation"
        case .rightIn:
            return "RightIn Animation"
        }
    }
}
extension Date {
    func dayOfWeek() -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "eeee"
        return dateFormatter.string(from: self).capitalized
        // or use capitalized(with: locale) if you want
    }
}
extension String {
    
    public func isImage() -> Bool {
        // Add here your image formats.
        let imageFormats = ["jpg", "jpeg", "png", "gif"]
        
        if let ext = self.getExtension() {
            return imageFormats.contains(ext)
        }
        
        return false
    }
    
    public func getExtension() -> String? {
        let ext = (self as NSString).pathExtension
        
        if ext.isEmpty {
            return nil
        }
        
        return ext
    }
    
    public func isURL() -> Bool {
        return URL(string: self) != nil
    }
    
}

extension UITextView {
    func setBottomBorder() {
        //self.borderStyle = .none
        self.layer.backgroundColor = UIColor.white.cgColor
        
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor(red: 0.0 / 255.0, green: 166.0 / 255.0, blue: 237.0 / 255.0, alpha: 1.0).cgColor
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        self.layer.shadowOpacity = 1.0
        self.layer.shadowRadius = 0.0
    }
}
extension UIColor {
    class var logoGreen: UIColor {
        return UIColor(red: 115.0 / 255.0, green: 181.0 / 255.0, blue: 29.0 / 255.0, alpha: 1.0)
    }
    class var logoBlue: UIColor {
        return UIColor(red: 65.0 / 255.0, green: 75.0 / 255.0, blue: 146.0 / 255.0, alpha: 1.0)
    }
    class var navigationColor: UIColor {
        return UIColor(red: 23.0 / 255.0, green: 54.0 / 255.0, blue: 95.0 / 255.0, alpha: 1.0)
    }
    class var statusbarColor: UIColor {
        return UIColor(red: 238.0 / 255.0, green: 239.0 / 255.0, blue: 239.0 / 255.0, alpha: 1.0)
    }
    
    class var imageborder: UIColor {
        return UIColor(red: 87.0 / 255.0, green: 193.0 / 255.0, blue: 220.0 / 255.0, alpha: 1.0)
    }
    class var textGray: UIColor {
        return UIColor(red: 102.0 / 255.0, green: 102.0 / 255.0, blue: 102.0 / 255.0, alpha: 1.0)
    }
    class var logoLightBlue: UIColor {
        return UIColor(red: 0.0 / 255.0, green: 166.0 / 255.0, blue: 237.0 / 255.0, alpha: 1.0)
    }
    class var defaultPurple: UIColor {
        return UIColor(red: 103.0 / 255.0, green: 58.0 / 255.0, blue: 183.0 / 255.0, alpha: 1.0)
    }
    
    class var defaultLightGray: UIColor {
        return UIColor(white: 224.0 / 255.0, alpha: 1.0)
    }
    
    class var defaultSteelGrey: UIColor {
        return UIColor(red: 121.0 / 255.0, green: 130.0 / 255.0, blue: 133.0 / 255.0, alpha: 1.0)
    }
    
    class var defaultGreyishBrown: UIColor {
        return UIColor(white: 74.0 / 255.0, alpha: 1.0)
    }
    
    class var defaultLightishGreen: UIColor {
        return UIColor(red: 76.0 / 255.0, green: 217.0 / 255.0, blue: 100.0 / 255.0, alpha: 1.0)
    }
    
    class var defaultCharcoalGrey: UIColor {
        return UIColor(red: 57.0 / 255.0, green: 57.0 / 255.0, blue: 58.0 / 255.0, alpha: 1.0)
    }
    class var defaultbrown: UIColor {
        return UIColor(red: 106.0 / 255.0, green: 81.0 / 255.0, blue: 42.0 / 255.0, alpha: 1.0)
    }
}

extension UIView {
    
    func fadeIn(duration: TimeInterval = 0.5,
                delay: TimeInterval = 0.0,
                completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in }) {
        UIView.animate(withDuration: duration,
                       delay: delay,
                       options: UIView.AnimationOptions.curveEaseIn,
                       animations: {
                        self.alpha = 1.0
        }, completion: completion)
    }
    
    func fadeOut(duration: TimeInterval = 0.5,
                 delay: TimeInterval = 0.0,
                 completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in }) {
        UIView.animate(withDuration: duration,
                       delay: delay,
                       options: UIView.AnimationOptions.curveEaseIn,
                       animations: {
                        self.alpha = 0.0
        }, completion: completion)
    }
}
extension UITextField {
    
    @IBInspectable var maxLength: Int {
        get {
            if let length = objc_getAssociatedObject(self, &kAssociationKeyMaxLength) as? Int {
                return length
            } else {
                return Int.max
            }
        }
        set {
            objc_setAssociatedObject(self, &kAssociationKeyMaxLength, newValue, .OBJC_ASSOCIATION_RETAIN)
            addTarget(self, action: #selector(checkMaxLength), for: .editingChanged)
        }
    }
    
    @objc func checkMaxLength(textField: UITextField) {
        guard let prospectiveText = self.text,
            prospectiveText.count > maxLength
            else {
                return
        }
        
        let selection = selectedTextRange
        
        let indexEndOfText = prospectiveText.index(prospectiveText.startIndex, offsetBy: maxLength)
        let substring = prospectiveText[..<indexEndOfText]
        text = String(substring)
        
        selectedTextRange = selection
    }
}
extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}
extension String
{
    var parseJSONString: AnyObject?
    {
        let data = self.data(using: String.Encoding.utf8, allowLossyConversion: false)
        if let jsonData = data
        {
            // Will return an object or nil if JSON decoding fails
            do
            {
                let message = try JSONSerialization.jsonObject(with: jsonData, options:.mutableContainers)
                if let jsonResult = message as? NSMutableArray {
                    return jsonResult //Will return the json array output
                } else if let jsonResult = message as? NSMutableDictionary {
                    return jsonResult //Will return the json dictionary output
                } else {
                    return nil
                }
            }
            catch let error as NSError
            {
                print("An error occurred: \(error)")
                return nil
            }
        }
        else
        {
            // Lossless conversion of the string was not possible
            return nil
        }
    }
}
public extension UIButton {
    
    func alignTextBelow(spacing: CGFloat = 6.0) {
        if let image = self.imageView?.image {
            let imageSize: CGSize = image.size
            self.titleEdgeInsets = UIEdgeInsets(top: spacing, left: -imageSize.width, bottom: -(imageSize.height), right: 0.0)
            let labelString = NSString(string: self.titleLabel!.text!)
            let titleSize = labelString.size(withAttributes: [NSAttributedString.Key.font: self.titleLabel!.font])
            self.imageEdgeInsets = UIEdgeInsets(top: -(titleSize.height + spacing), left: 0.0, bottom: 0.0, right: -titleSize.width)
        }
    }
    
}
@IBDesignable extension UIButton {
    
    @IBInspectable var borderWidthbutton: CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    
    @IBInspectable var cornerRadiusbutton: CGFloat {
        set {
            layer.cornerRadius = newValue
        }
        get {
            return layer.cornerRadius
        }
    }
    
    @IBInspectable var borderColorbutton: UIColor? {
        set {
            guard let uiColor = newValue else { return }
            layer.borderColor = uiColor.cgColor
        }
        get {
            guard let color = layer.borderColor else { return nil }
            return UIColor(cgColor: color)
        }
    }
}
extension String {
    func contains(find: String) -> Bool{
        return self.range(of: find) != nil
    }
    func containsIgnoringCase(find: String) -> Bool{
        return self.range(of: find, options: .caseInsensitive) != nil
    }
}
extension UIImageView {
    
    func roundedImage() {
        self.layer.cornerRadius = self.frame.size.width / 2
        self.layer.borderWidth = 2
        self.layer.borderColor = UIColor.imageborder.cgColor
        self.clipsToBounds = true
        self.contentMode = UIView.ContentMode.scaleAspectFill
        
    }
    
}
typealias AlertActionHandler = ((UIAlertAction) -> Void)

extension UIAlertController.Style {
    
    func controller(title: String, message: String, actions: [UIAlertAction]) -> UIAlertController {
        let _controller = UIAlertController(
            title: title,
            message: message,
            preferredStyle: self
        )
        actions.forEach { _controller.addAction($0) }
        return _controller
    }
}
extension CGRect{
    init(_ x:CGFloat,_ y:CGFloat,_ width:CGFloat,_ height:CGFloat) {
        self.init(x:x,y:y,width:width,height:height)
    }
    
}
extension CGSize{
    init(_ width:CGFloat,_ height:CGFloat) {
        self.init(width:width,height:height)
    }
}
extension CGPoint{
    init(_ x:CGFloat,_ y:CGFloat) {
        self.init(x:x,y:y)
    }
}
extension UIColor {
    convenience init(hexString: String, alpha: CGFloat = 1.0) {
        let hexString: String = hexString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let scanner = Scanner(string: hexString)
        
        if (hexString.hasPrefix("#")) {
            scanner.scanLocation = 1
        }
        
        var color: UInt32 = 0
        scanner.scanHexInt32(&color)
        
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        
        self.init(red:red, green:green, blue:blue, alpha:alpha)
    }
    
    func toHexString() -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        
        getRed(&r, green: &g, blue: &b, alpha: &a)
        
        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        
        return String(format:"#%06x", rgb)
    }
}
extension String {
    
    func alertAction(style: UIAlertAction.Style = .default, handler: AlertActionHandler? = nil) -> UIAlertAction {
        return UIAlertAction(title: self, style: style, handler: handler)
    }
}
struct MyVariables {
    static var selectedVisitor = ""
    static var selectedVisitorid = ""
    static var selectedpersonName = ""
    static var selectedpersonid = ""
}
//Validation
extension String {
    func isValidEmail() -> Bool {
        // here, `try!` will always succeed because the pattern is valid
        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil
    }
}
extension String
{
    var isValidContact: Bool {
        let phoneNumberRegex = "^[6-9]\\d{9}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        let isValidPhone = phoneTest.evaluate(with: self)
        return isValidPhone
    }
}

extension String {
    
    //To check text field or String is blank or not
    var isBlank: Bool {
        get {
            let trimmed = trimmingCharacters(in: CharacterSet.whitespaces)
            return trimmed.isEmpty
        }
    }
}
extension String {
    
    public func isPhone()->Bool {
        if self.isAllDigits() == true {
            let phoneRegex = "[235689][0-9]{6}([0-9]{3})?"
            let predicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
            return  predicate.evaluate(with: self)
        }else {
            return false
        }
    }
    
    private func isAllDigits()->Bool {
        let charcterSet  = NSCharacterSet(charactersIn: "+0123456789").inverted
        let inputString = self.components(separatedBy: charcterSet)
        let filtered = inputString.joined(separator: "")
        return  self == filtered
    }
}

extension Notification.Name {
     static let refreshmyprofile = Notification.Name("refreshmyprofile")
     static let refreshnotification = Notification.Name("refreshnotification")
     static let refreshnotificationAPNS = Notification.Name("refreshnotificationAPNS")
    
    static let refreshparents = Notification.Name("refreshparents")
    static let refreshparentsoff = Notification.Name("refreshparentsoff")
     static let refreshhome = Notification.Name("refreshhome")
    static let refreshAnnouncement = Notification.Name("refreshAnnouncement")
    static let refreshlearning = Notification.Name("refreshlearning")
     static let refreshEvent = Notification.Name("refreshEvent")
    static let refreshreport = Notification.Name("refreshreport")
    static let refreshcalendar = Notification.Name("refreshcalendar")
    static let refreshStudentAttendance = Notification.Name("refreshStudentAttendance")
    static let refreshTransition = Notification.Name("refreshTransition")
     static let refreshModeration = Notification.Name("refreshModeration")
     static let refreshModerationDetail = Notification.Name("refreshModerationDetail")
    static let refreshModerationDetailchat = Notification.Name("refreshModerationDetailchat")
     static let refreshuserProfile = Notification.Name("refreshuserProfile")
     static let refreshmore = Notification.Name("refreshmore")
    static let refreshsearch = Notification.Name("refreshsearch")
    static let refreshmember = Notification.Name("refreshmember")
    static let refreshmemberdetail = Notification.Name("refreshmemberdetail")
    static let addmember = Notification.Name("addmember")
    static let addmemberNil = Notification.Name("addmemberNil")
    static let updateProfile = Notification.Name("updateProfile")
    static let addfavorite = Notification.Name("addfavorite")
    static let didReceiveData = Notification.Name("didReceiveData")
    static let didReceiveDataApprove = Notification.Name("didReceiveDataApprove")
    static let refreshApprove = Notification.Name("refreshApprove")
    static let refreshPreapprove = Notification.Name("refreshPreapprove")
    static let poptoVisitor = Notification.Name("poptoVisitor")
    static let refreshchatlist = Notification.Name("refreshchatlist")
    static let refreshnotificationAPNSForCounter = Notification.Name("refreshnotificationAPNSForCounter")
     static let refreshuserProfileStudent = Notification.Name("refreshuserProfileStudent")
    static let refresCounterWhenActive = Notification.Name("refresCounterWhenActive")
    
    
}

extension UITextView {
    func addBottomBorderWithColor(color: UIColor, height: CGFloat) {
        let border = UIView()
        border.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        border.frame = CGRect(self.frame.origin.x,
                              self.frame.origin.y+self.frame.height-height, self.frame.width, height)
        border.backgroundColor = color
        self.superview!.insertSubview(border, aboveSubview: self)
    }
}
extension UIView {
    
    /// Flip view horizontally.
    func flipX() {
        transform = CGAffineTransform(scaleX: -transform.a, y: transform.d)
    }
    
    /// Flip view vertically.
    func flipY() {
        transform = CGAffineTransform(scaleX: transform.a, y: -transform.d)
    }
}
extension UITextField {
    
    func useUnderline() {
        
        let border = CALayer()
        let borderWidth = CGFloat(1.0)
        border.borderColor = UIColor.gray.cgColor
        // border.frame = CGRectMake(0, self.frame.size.height - borderWidth, self.frame.size.width, self.frame.size.height)
        border.frame = CGRect(0, self.frame.size.height - borderWidth, self.frame.size.width, self.frame.size.height)
        border.borderWidth = borderWidth
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
}
extension UIColor {
    convenience init(rgb: UInt) {
        self.init(
            red: CGFloat((rgb & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgb & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgb & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
extension Error {
    var code: Int { return (self as NSError).code }
    var domain: String { return (self as NSError).domain }
}
@IBDesignable
class CardView: UIView {
    
    // @IBInspectable var cornerRadius CGFloat = 2
    
    @IBInspectable var shadowOffsetWidth: Int = 0
    @IBInspectable var shadowOffsetHeight: Int = 1
    @IBInspectable var shadowColor: UIColor? = UIColor.black
    @IBInspectable var shadowOpacity: Float = 0.2
    
    override func layoutSubviews() {
        layer.cornerRadius = cornerRadius
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius)
        
        layer.masksToBounds = false
        layer.shadowColor = shadowColor?.cgColor
        layer.shadowOffset = CGSize(width: shadowOffsetWidth, height: shadowOffsetHeight);
        layer.shadowOpacity = shadowOpacity
        layer.shadowPath = shadowPath.cgPath
    }
    
}
extension UIImage {
    
    func fixedOrientation() -> UIImage? {
        
        guard imageOrientation != UIImage.Orientation.up else {
            //This is default orientation, don't need to do anything
            return self.copy() as? UIImage
        }
        
        guard let cgImage = self.cgImage else {
            //CGImage is not available
            return nil
        }
        
        guard let colorSpace = cgImage.colorSpace, let ctx = CGContext(data: nil, width: Int(size.width), height: Int(size.height), bitsPerComponent: cgImage.bitsPerComponent, bytesPerRow: 0, space: colorSpace, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            return nil //Not able to create CGContext
        }
        
        var transform: CGAffineTransform = CGAffineTransform.identity
        
        switch imageOrientation {
        case .down, .downMirrored:
            transform = transform.translatedBy(x: size.width, y: size.height)
            transform = transform.rotated(by: CGFloat.pi)
            break
        case .left, .leftMirrored:
            transform = transform.translatedBy(x: size.width, y: 0)
            transform = transform.rotated(by: CGFloat.pi / 2.0)
            break
        case .right, .rightMirrored:
            transform = transform.translatedBy(x: 0, y: size.height)
            transform = transform.rotated(by: CGFloat.pi / -2.0)
            break
        case .up, .upMirrored:
            break
        }
        
        //Flip image one more time if needed to, this is to prevent flipped image
        switch imageOrientation {
        case .upMirrored, .downMirrored:
            transform.translatedBy(x: size.width, y: 0)
            transform.scaledBy(x: -1, y: 1)
            break
        case .leftMirrored, .rightMirrored:
            transform.translatedBy(x: size.height, y: 0)
            transform.scaledBy(x: -1, y: 1)
        case .up, .down, .left, .right:
            break
        }
        
        ctx.concatenate(transform)
        
        switch imageOrientation {
        case .left, .leftMirrored, .right, .rightMirrored:
            ctx.draw(self.cgImage!, in: CGRect(x: 0, y: 0, width: size.height, height: size.width))
        default:
            ctx.draw(self.cgImage!, in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
            break
        }
        
        guard let newCGImage = ctx.makeImage() else { return nil }
        return UIImage.init(cgImage: newCGImage, scale: 1, orientation: .up)
    }
}
