//
//  Network.swift


import UIKit
//import ObjectMapper

let AppBaseUrl = "http://api.kcdev.pro/v2/auth?"

class CommonApi {

//MARK: - Properties
    

    static let loginApi = ""

    
  


//MARK: - Login Api's
  
    class func LoginApi(handler: @escaping ResultHandler) {
        
        Network.commonRequest(url: loginApi, method: .post, parameters:registerPram as? [String : Any], headers: ["Accept": "application/json",]) { (success, jsonValue, error) in
            if success
            {
                 let list = jsonValue as! [String:AnyObject]
                
                handler(success, list, nil)
            } else
            {
                handler(success, nil, error)
            }
        }
    }
    

}
