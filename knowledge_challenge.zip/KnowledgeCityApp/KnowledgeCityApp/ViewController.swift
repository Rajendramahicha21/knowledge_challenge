//
//  ViewController.swift
//  KnowledgeCityApp
//
//  Created by Rajendra on 20/09/19.
//  Copyright © 2019 Rajendra. All rights reserved.
//

import UIKit
import SVProgressHUD
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var rememberMeBtn: UIButton!
    
    
    var rememberMe : Bool = false
    var remember = NSString()
    
    
    
    //MARK: - viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        self.navigationItem.setHidesBackButton(true, animated:true);
        
        //Set placeholder image in textfeild
        txtUsername.setLeftView(image: UIImage.init(named: "user")!)
        txtUsername.tintColor = .darkGray
        txtUsername.isSecureTextEntry = false
        
        //Set placeholder image in textfeild
        txtPassword.setLeftView(image: UIImage.init(named: "password")!)
        txtPassword.tintColor = .darkGray
        txtPassword.isSecureTextEntry = true
        
        
        // This code for remember me
        if UserDefaults.standard.string(forKey: "savedIsRemember") != nil {
            
                let  username =  UserDefaults.standard.string(forKey: "SavedUsername")! as NSString
                let  password =  UserDefaults.standard.string(forKey: "SavedPassword")! as NSString
                
                txtUsername.text = username as String
                txtPassword.text = password as String

        }

    }
    
    
    //MARK: - Remember Me Button Action
    @IBAction func rememberMeClicked(_ sender: Any) {
        
        var image = rememberMeBtn.currentImage
        
        if(image == UIImage(named:"check_1")){
            
            image = UIImage(named:"check_2")
            rememberMeBtn.setImage(image, for: .normal)
            self.rememberMe = true
            
             remember = "isRemember"
             UserDefaults.standard.set(remember, forKey: "savedIsRemember")
            
            UserDefaults.standard.set(txtUsername.text, forKey: "SavedUsername")
            UserDefaults.standard.set(txtPassword.text, forKey: "SavedPassword")
            
        } else {
            
            image = UIImage(named:"check_1")
            rememberMeBtn.setImage(image, for: .normal)
            self.rememberMe = false
            
           UserDefaults.standard.removeObject(forKey: "SavedUsername")
           UserDefaults.standard.removeObject(forKey: "SavedPassword")
            UserDefaults.standard.removeObject(forKey: "savedIsRemember")
        }
    }
    
     //MARK: - Login Button Action
    @IBAction func btnLoginAction(_ sender: Any) {
        
        if self.rememberMe == false
        {
            UserDefaults.standard.removeObject(forKey: "SavedUsername")
            UserDefaults.standard.removeObject(forKey: "SavedPassword")
            UserDefaults.standard.removeObject(forKey: "savedIsRemember")
        }
        
        if (txtUsername.text?.isEmpty)! {
            
            let alert = UIAlertController(title: "", message:  .enter_username, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        else if (txtPassword.text?.isEmpty)! {
            
            let alert = UIAlertController(title: "", message: .enter_password, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        else{
            self.CallApiSignIn()
        }
        
    }
    //MARK: - Call api for login
    func CallApiSignIn()
        
        {
            
             SVProgressHUD.show(withStatus: "Logging in")
             
             let url = "http://api.kcdev.pro/v2/auth"
             let username:String = txtUsername.text!
             let pass:String = txtPassword.text!
             let parameters: Parameters = [
                "usertype": "accountAdmin",
                "_extend": "user",
             "username": username,
             "password": pass
             ]

             Alamofire.request(url, method: .post, parameters: parameters, encoding: URLEncoding.httpBody,headers: nil).responseJSON
             {
             response in
             switch response.result
             {
             case .success:
                
                if let JSON = response.result.value as? [String: Any] {
                    
                    
                     let status = JSON["status"] as! String
                    
                    if status == "Unauthorized"{
                        
                        
                        let alert = UIAlertController(title: "", message: "Incorrect login/password Try again", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        SVProgressHUD.dismiss()
                        
                    }
                    else{
                        dicLoginUserData  = JSON["response"] as! NSDictionary
                        let dicuser = dicLoginUserData.value(forKey: "user") as! NSDictionary
                        
                        loginAccessToken = dicLoginUserData["token"] as! NSString
                        loginAccount_id = dicuser["account_id"] as! NSString
                        
                        
                        //for saving login token in userDefalts
                        UserDefaults.standard.set(loginAccessToken, forKey: "SavedLoginAccessToken")
                        
                        //for saving Account Id in userDefalts
                        UserDefaults.standard.set(loginAccount_id, forKey: "SavedAccountId")
                        

                        SVProgressHUD.dismiss()
                        
                        let objvc = self.storyboard?.instantiateViewController(withIdentifier: "UserListVC") as! UserListVC
                        self.navigationController? .pushViewController(objvc, animated: true)
                    }
                    
              break
                }
             case .failure(let error):
                //error handling
                print(error)
                
                let alert = UIAlertController(title: "", message: .no_internet, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
                SVProgressHUD.dismiss()
                
                }
        
                }}}
//MARK: - Extension for textfeild image
extension UITextField {
    func setLeftView(image: UIImage) {
        let iconView = UIImageView(frame: CGRect(x: 10, y: 7, width: 25, height: 30)) // set your Own size
        iconView.image = image
        let iconContainerView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 35, height: 45))
        iconContainerView.addSubview(iconView)
        leftView = iconContainerView
        leftViewMode = .always
        self.tintColor = .lightGray
    }
}
