//
//  UserListCell.swift
//  KnowledgeCityApp
//
//  Created by Rajinder on 20/09/19.
//  Copyright © 2019 Rajendra. All rights reserved.
//

import UIKit

class UserListCell: UITableViewCell {
    
    @IBOutlet weak var lblUsername: UILabel!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblGroup: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
