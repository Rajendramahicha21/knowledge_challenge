//
//  UserListVC.swift
//  KnowledgeCityApp
//
//  Created by Rajendra on 20/09/19.
//  Copyright © 2019 Rajendra. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

class UserListVC: UIViewController {

    @IBOutlet weak var tableUser: UITableView!
    
     var loginAccessToken = NSString()
     var accountID = NSString()
     var arrayUsers = NSMutableArray()
    @IBOutlet weak var viewBottom: UIView!
    
    //==============
    var isDataLoading:Bool=false
    var pageNo:Int=0
    var limit:Int=5
    var offset:Int=0 //pageNo*limit
    var didEndReached:Bool=false
     var myString = String()
    var rowCount = Int()
    //==============
    
     // MARK: - viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myString = "0"
        
        //Retrieve loginAccessToken And AccountId from userDefaults
        loginAccessToken =  UserDefaults.standard.string(forKey: "SavedLoginAccessToken")! as NSString
        accountID =  UserDefaults.standard.string(forKey: "SavedAccountId")! as NSString
        
        self.tableUser.isHidden = true
        self.viewBottom.isHidden = true

        self.title = "User List"
        self.navigationItem.setHidesBackButton(true, animated:true);

        
          tableUser.register(UINib(nibName: "UserListCell", bundle: nil), forCellReuseIdentifier: "UserListCell")
       
    }
    override func viewWillAppear(_ animated: Bool) {
         CallApiUserList()
    }
    
     // MARK: - Log out button action
    @IBAction func logOutButtonAtion(_ sender: Any) {
        
        let alert = UIAlertController(title: "Log Out", message: .signout_text, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
            
            self.CallApiForLogOut()
            
        }))
        
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        
        self.present(alert, animated: true)
    }
    
    //MARK: - Call api for Users List
    func CallApiUserList()
    {

        SVProgressHUD.show(withStatus: "Fetching Users")
        let url = "https://api.kcdev.pro/v2/accounts/"
        let finalurl = url + (accountID as String) + "/students?";
            let parameters: Parameters = [
                "_start": myString,
                "_limit": "5",
                "token": loginAccessToken
            ]

        Alamofire.request(finalurl, method: .get, parameters: parameters, encoding: URLEncoding.default)
            .responseJSON { response in
                    switch response.result
                    {
                    case .success:
                        
                        if let JSON = response.result.value as? [String: Any] {
                            
                        let arrdata = JSON["response"] as! NSArray
                            
                            
                             let data = JSON["pagination"] as! NSDictionary
                            self.rowCount = (data["totalRecords"] as! Int)
                            
                            
                            self.arrayUsers = arrdata.mutableCopy() as! NSMutableArray
                            
                            self.tableUser.reloadData()
                            self.tableUser.isHidden = false
                            self.viewBottom.isHidden = false
                            
                            SVProgressHUD.dismiss()
                          
                            break
                        }
                    case .failure(let error):
                        //error handling
                        print(error)
                        SVProgressHUD.dismiss()
                    }

        }}
    
    //MARK: - Call api for Load more
    
    func CallApiUserListLoadMore()
    {
        
        let url = "https://api.kcdev.pro/v2/accounts/"
        let finalurl = url + (accountID as String) + "/students?";
        let parameters: Parameters = [
            "_start": myString,
            "_limit": "5",
            "token": loginAccessToken
        ]
        
        Alamofire.request(finalurl, method: .get, parameters: parameters, encoding: URLEncoding.default)
            .responseJSON { response in
                switch response.result
                {
                case .success:
                    
                    if let JSON = response.result.value as? [String: Any] {
                        
                        
                        let arrdata = JSON["response"] as! NSArray
                        self.arrayUsers.addObjects(from: (arrdata  as! [Any]))
                        self.tableUser.reloadData()
                        
                        SVProgressHUD.dismiss()
                        
                        break
                    }
                case .failure(let error):
                    //error handling
                    print(error)
                    SVProgressHUD.dismiss()
                }
                
        }}

//MARK: - Call api for log out
func CallApiForLogOut()
    
{
    
    SVProgressHUD.show(withStatus: "Log Out")
    let url = "http://api.kcdev.pro/v2/auth"
    let parameters: Parameters = ["token": loginAccessToken]
    
    Alamofire.request(url, method: .delete, parameters: parameters, encoding: URLEncoding.default)
        .responseJSON { response in
            switch response.result
            {
            case .success:
                
                if let JSON = response.result.value as? [String: Any] {
                    
                     SVProgressHUD.dismiss()
                let message = JSON["response"] as! String
                    self.toastMessage(message)
                    
                    let objVc = self.storyboard!.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                    self.navigationController?.pushViewController(objVc, animated:true)
                    
                    break
                }
            case .failure(let error):
                //error handling
                print(error)
                SVProgressHUD.dismiss()
            }
            
    }}

    // MARK: - Pagination
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        
        isDataLoading = false
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        if ((tableUser.contentOffset.y + tableUser.frame.size.height) >= tableUser.contentSize.height)
        {
            if !isDataLoading{
                isDataLoading = true
                self.pageNo=self.pageNo+1
                self.limit=self.limit+5
               
                self.myString = String(self.pageNo)
                self.offset=self.limit * self.pageNo
                
                if self.rowCount > self.arrayUsers.count {
                
                CallApiUserListLoadMore()
                }
            }
        }
        
        
    }
    
}

// MARK: - Table View Data Source

extension UserListVC: UITableViewDataSource, UITableViewDelegate
{
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 25))
        headerView.backgroundColor = UIColor( red: CGFloat(233/255.0), green: CGFloat(140/255.0), blue: CGFloat(52/255.0), alpha: CGFloat(1.0) )
        return headerView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 25
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayUsers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserListCell", for: indexPath as IndexPath) as! UserListCell
        cell.selectionStyle = .none
        
        var dicuserDetail = NSDictionary()
         dicuserDetail = self.arrayUsers[indexPath.row] as! NSDictionary
        
        
        cell.lblUsername.text = dicuserDetail.value(forKey: "username") as? String
        cell.lblGroup.text = dicuserDetail.value(forKey: "group") as? String
        
        let strFirstName = dicuserDetail.value(forKey: "first_name")as? String
        let strLastName = dicuserDetail.value(forKey: "last_name")as? String
        cell.lblName.text = strFirstName! + " " + strLastName!
        
        
        
        
        
        if indexPath.row%2==0 {
            cell.backgroundColor = UIColor( red: CGFloat(235/255.0), green: CGFloat(235/255.0), blue: CGFloat(237/255.0), alpha: CGFloat(1.0) )
        }
        else{
            
            cell.backgroundColor = UIColor.white
        }
        

        
        
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }
}

// MARK: - Show Tost Alert
extension UserListVC {
    
    func toastMessage(_ message: String){
        guard let window = UIApplication.shared.keyWindow else {return}
        let messageLbl = UILabel()
        messageLbl.text = message
        messageLbl.textAlignment = .center
        messageLbl.font = UIFont.systemFont(ofSize: 12)
        messageLbl.textColor = .white
        messageLbl.backgroundColor = UIColor(white: 0, alpha: 0.5)
        
        let textSize:CGSize = messageLbl.intrinsicContentSize
        let labelWidth = min(textSize.width, window.frame.width - 40)
        
        messageLbl.frame = CGRect(x: 20, y: window.frame.height - 90, width: labelWidth + 30, height: textSize.height + 20)
        messageLbl.center.x = window.center.x
        messageLbl.layer.cornerRadius = messageLbl.frame.height/2
        messageLbl.layer.masksToBounds = true
        window.addSubview(messageLbl)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            
            UIView.animate(withDuration: 1, animations: {
                messageLbl.alpha = 0
            }) { (_) in
                messageLbl.removeFromSuperview()
            }
        }
    }
    }
